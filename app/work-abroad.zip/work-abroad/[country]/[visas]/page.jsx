



import Nav from "./Nav";

import Two from "./Two";

export async function generateMetadata({ params }) {
  const { country, visas } = await params;

  const pageKey = `${country}-${visas}`;

  switch (pageKey) {
    case "canada-work-permit-lmia":
      return {
        title: "Canada LMIA Work Permit Process & Requirements | VJC",
      };
     case "australia-work-permit-work-visa-subclass-189":
    return {
      title: "Australia 189 Work Visa Process & Requirements | VJC",
    };

case "dubai-work-permit-dubai-standard-work-visa":
  return {
    title: "Dubai Work Visa Process & Requirements | VJC",
  };
    default:
      return {};
  }
}
const textContainerVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.3,
      duration: 0.8,
      ease: "easeOut",
    },
  },
};




const ContactPage = () => {
  

  

  return (
    <>
      {/* Navbar */}
      <div style={{ marginTop: "5%", zIndex: 20, position: "relative" }}>
        <Nav />
      </div>

      {/* Main Section */}
     

      {/* Other Sections */}
      <Two />
    </>
  );
};

export default ContactPage;
